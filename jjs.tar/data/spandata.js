
(function(jigLib){
	/**
	* @author katopz
	*/
	var SpanData=function(){};
	SpanData.prototype.min=null;
	SpanData.prototype.max=null;
	SpanData.prototype.flag=null;
	SpanData.prototype.depth=null;
	
	jigLib.SpanData=SpanData;
})(jigLib);