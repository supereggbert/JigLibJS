(function(jigLib){
	/**
		 * @author katopz
		 */
	var ContactData=function(){};
	ContactData.prototype.pair=null;
	ContactData.prototype.impulse=null;
	
	jigLib.ContactData=ContactData;
})(jigLib);

