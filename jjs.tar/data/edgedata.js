
(function(jigLib){
	/**
	* @author katopz
	*/
	var EdgeData=function(ind0, ind1){
		this.ind0 = ind0;
		this.ind1 = ind1;
	};
	
	jigLib.EdgeData=EdgeData;
})(jigLib);